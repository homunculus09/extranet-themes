(function() {
    // Function to apply dark theme
    function applyDarkTheme() {
        // Load the CSS from the specified URL
        var cssUrl = 'https://raw.githubusercontent.com/homunculus09/extranet-themes/refs/heads/main/default-dark/default-dark-stylesheet.css';

        fetch(cssUrl)
            .then(response => response.text())
            .then(cssContent => {
                // Remove any existing stylesheets or style tags
                var oldStyles = document.querySelectorAll('link[rel="stylesheet"], style');
                oldStyles.forEach(style => style.remove());

                // Create and apply new style element
                var styleElement = document.createElement('style');
                styleElement.innerHTML = cssContent;
                document.head.appendChild(styleElement);
            })
            .catch(error => console.error('Failed to load CSS:', error));
    }

    // Apply dark theme immediately on page load
    applyDarkTheme();

    // Observe DOM changes to reapply dark theme when navigating within the site
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            // When DOM changes, reapply the dark theme
            applyDarkTheme();
        });
    });

    // Start observing the document body for changes in child nodes
    observer.observe(document.body, { childList: true, subtree: true });

})();
